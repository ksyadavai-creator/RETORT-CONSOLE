# RETORT PRO — Industrial Retort Management Software

A complete, offline-first retort process management web app. Runs entirely
in the browser — no server, no signup, no cost. All data is stored in the
browser's `localStorage` on your own device.

## How to run it

**Easiest:** Just double-click `index.html` to open it in Chrome/Edge/Firefox.
(Works fully offline once the page has loaded the CDN libraries once with
an internet connection — Bootstrap, Chart.js, jsPDF, SheetJS are loaded
from CDN links in `index.html`.)

**Recommended (avoids browser file:// restrictions on some systems):**
Run a tiny local server from this folder, then open the printed address:
```
python3 -m http.server 8080
```
or, if you have Node:
```
npx serve .
```

**To host it for free:** drag-and-drop this whole folder into
[Netlify Drop](https://app.netlify.com/drop), or push it to a GitHub repo
and enable GitHub Pages — both are free static hosting, which fits your
"free plan" requirement perfectly since there is no backend to pay for.

## Full deployment roadmap
Open **DEPLOYMENT_ROADMAP.html** in this folder by double-clicking it — it
opens directly in your browser like a webpage (no special app needed). A
plain-text version is also included as DEPLOYMENT_ROADMAP.md.

## Folder structure
```
RetortPro/
  index.html          Login + application shell, loads every module
  css/style.css        Steel & Signal theme — white/blue industrial UI, dark mode
    js/
      storage.js         LocalStorage CRUD database layer
      products.js         188 auto-generated retort products + Product Library view
      stock.js            Stock/Inventory management — raw materials, packaging
                           materials, finished goods, stock-in/out, low-stock alerts
      calculator.js       F0 lethality engine (Σ Δt·10^((T-Tref)/z)) + Calculator view
      batch.js            New Batch form, live timer, temperature logging
      dashboard.js         Dashboard hero, KPI cards, pass/fail chart, machine status
      graph.js            Temperature / Pressure / F0 interactive Chart.js graphs
      guide.js            Process Guide — SOP/HACCP/CCP per packaging type
      report.js           PDF (jsPDF), Excel (SheetJS) and Print report generation
      settings.js          Company profile, theme, backup/restore
      app.js              Router, login, theme, clock, History/Alarms/Users views
  data/products.json    Static export of the 163-product library (reference only —
                         the app itself seeds this data automatically into
                         localStorage the first time it runs, so no fetch() is
                         needed and it works from a plain file:// double-click)
  assets/               Reserved for your company logo (upload it from
                         Settings → Company Profile instead — it's stored as
                         a data URL in localStorage, no file needed here)
```

## What actually works
- Login with role selection (Admin/Production/QA/Operator) — stored locally
- New Batch: full form, auto batch numbering, live batch timer, per-minute
  temperature/pressure logging, live F0 + PASS/FAIL evaluation with warnings
- F0 Calculator: standalone lethality calculator with editable z-value and
  reference temperature, lethality curve chart
- Product Library: 188 real product/packaging combinations, searchable and
  filterable, "Use in New Batch" auto-fills the batch form
- Stock Management: raw materials, packaging materials and finished goods
  inventory, Stock-In/Stock-Out transactions with reason & reference, low-stock
  alerts on the dashboard, movement log
- Process Guide: full SOP + HACCP/CCP + common mistakes for all 10 packaging types
- Graphs: Temperature/Pressure/F0 vs time for any saved batch
- Reports: real PDF export (with tables), real Excel export (2 sheets), Print
- History: search/filter by batch number, product, date, machine, status;
  edit and delete batches
- Alarms: aggregated from real batch warning data (temp/pressure/holding/
  cooling/F0 shortfalls)
- Settings: company name/logo, units, language, z-value/ref temp defaults,
  light/dark theme, full JSON backup & restore
- User Management: role/permission reference table

## Notes on scope
This is a genuine offline single-device tool (no backend, no real
authentication/security) — appropriate for a free-plan deployment. If you
later need multi-user login with real access control, QR/barcode label
printing, or a shared/synced database across machines, that requires a
backend server and is a separate project from this static app.
