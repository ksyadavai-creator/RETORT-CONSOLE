# RETORT PRO — Complete Deployment Roadmap

A step-by-step path from "works on my PC" to "live and used by my team,"
free, with no server to hack, crash, or leak data from.

---

## PHASE 0 — Test locally (today, 15 minutes)
1. Extract the ZIP, double-click `index.html`.
2. First screen will ask you to **create the Admin account** (your name,
   email/phone, a 4–6 digit PIN). This only happens once, ever.
3. Add one test batch, one stock item, generate one PDF report — confirm
   everything works before anyone else touches it.
4. Go to **User Management** (Admin only) → Add one test Operator account →
   log out → log back in as that Operator → confirm they can't see User
   Management (Admin-only lock working).

**Exit criteria:** you're logged in as Admin, dashboard shows real data, PDF
downloaded successfully.

---

## PHASE 1 — Go live for free (this week, 15–30 minutes)
Pick **one** of these — all are genuinely free, no credit card required:

| Option | Best for | Steps |
|---|---|---|
| **Netlify Drop** | Fastest, zero setup | Drag the `retortpro` folder onto app.netlify.com/drop |
| **Vercel** | If you'll update it via GitHub later | Push to GitHub → Import on vercel.com |
| **GitHub Pages** | If you already use GitHub | Push to a repo → Settings → Pages → enable |
| **Cloudflare Pages** | Fastest loading worldwide | Same drag/import flow at pages.cloudflare.com |

You'll get a live HTTPS link (e.g. `retortpro.netlify.app`) in minutes.

**Exit criteria:** the live link opens on your phone and a colleague's phone,
both able to create their own Admin/login as normal.

---

## PHASE 2 — Roll out to your team (week 2)
1. As Admin, add each real team member in **User Management** with their
   own email/phone + a PIN you set and hand them directly.
2. Ask everyone to **bookmark** the live link (not the local file).
3. **Important limitation to explain to your team:** each *device* has its
   own separate local data. If Ramesh logs in on the factory tablet, his
   batches are saved to that tablet, not "in the cloud." This is what makes
   the app free and unhackable — but it means:
   - Use **one shared device per production line** (e.g. one tablet at
     Retort #1), not each person's personal phone, if you want batch data
     from one line in one place.
   - Every Friday (or after every shift), Admin goes to **Settings →
     Download Backup (.json)** and saves it to Google Drive / email to
     yourself. This is your safety net against someone clearing browser data.

**Exit criteria:** every real team member has logged in once successfully,
first weekly backup downloaded and saved somewhere off the device.

---

## PHASE 3 — Optional: your own domain (whenever you're ready)
- Buy a domain (~₹700–1,200/year) from Namecheap/GoDaddy/BigRock, e.g.
  `retortpro.in` or `yourcompany-retort.com`.
- In your hosting provider's dashboard (Netlify/Vercel/Cloudflare), add it
  as a Custom Domain. HTTPS certificate is issued automatically and free.
- This step is purely cosmetic/branding — the app is exactly as functional
  and exactly as secure without it.

---

## PHASE 4 — Optional: real multi-device sync / sell it to other companies
Only pursue this if Phase 2's "one device per line + weekly backup" model
genuinely isn't enough — e.g. you want batch data to appear instantly across
every device, or you want to sell RetortPro as a subscription product to
other food companies.

This needs the backend already built for you (`RetortPro-Backend.zip`):
a real server + database + Razorpay subscriptions. It is a different,
larger undertaking with its own costs (small hosting fee, Razorpay KYC,
ongoing server maintenance) and its own security model (that backend's
README covers JWT secrets, webhook verification, etc. in detail). Don't
start this phase until Phases 0–2 are working smoothly — most factories
never actually need it.

---

## Security & reliability summary (what "no hack, no crash, no leak" means here)
- **No hack**: Phases 0–3 involve zero server code — static files only.
  There's nothing running that an attacker can exploit.
- **No crash**: static file hosting on Netlify/Vercel/Cloudflare/GitHub runs
  on infrastructure built for millions of sites; a factory team's traffic
  is not a meaningful load.
- **No data leak**: nothing is transmitted anywhere — all batch/stock/user
  data lives in each device's own browser storage. PINs are never stored in
  plain text (SHA-256 hashed with a random salt using the browser's built-in
  Web Crypto API — no external library, nothing to go out of date).
- **Honest limit, stated plainly**: client-side PIN checks stop casual
  access by coworkers, not a determined attacker with physical access to
  the device and browser dev tools open. That's the correct, honest
  security level for a shared factory tablet — the same level as, say, a
  PIN-locked point-of-sale tablet. If you need protection against that
  threat model specifically, that requires Phase 4's real backend.

## If something goes wrong
- **Forgot the only Admin's PIN?** There's no "forgot password" flow (no
  server to send a reset email/SMS from). Recovery is: Settings → **Erase
  All Local Data** (only on that specific device) and set up a fresh Admin
  — this is why weekly JSON backups matter, so you can restore batch/stock
  history via **Settings → Restore from File** right after.
- **App looks broken after an update?** Hard-refresh the browser
  (Ctrl+Shift+R / Cmd+Shift+R) — static hosting sometimes caches the old
  version for a few minutes after you redeploy.
